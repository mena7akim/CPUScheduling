package Schedulers;

interface Scheduler {
    void addProcesses(Process[] processes);

    void runScheduler();

}
